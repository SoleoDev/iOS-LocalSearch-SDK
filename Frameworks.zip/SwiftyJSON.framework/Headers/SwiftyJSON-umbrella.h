#import <UIKit/UIKit.h>


FOUNDATION_EXPORT double SwiftyJSONVersionNumber;
FOUNDATION_EXPORT const unsigned char SwiftyJSONVersionString[];

