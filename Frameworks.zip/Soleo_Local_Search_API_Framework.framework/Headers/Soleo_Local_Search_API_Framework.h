//
//  Soleo_Local_Search_API_Framework.h
//  Soleo_Local_Search_API_Framework
//
//  Created by Victor Jimenez Delgado on 4/7/16.
//  Copyright © 2016 Soleo. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Soleo_Local_Search_API_Framework.
FOUNDATION_EXPORT double Soleo_Local_Search_API_FrameworkVersionNumber;

//! Project version string for Soleo_Local_Search_API_Framework.
FOUNDATION_EXPORT const unsigned char Soleo_Local_Search_API_FrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Soleo_Local_Search_API_Framework/PublicHeader.h>


